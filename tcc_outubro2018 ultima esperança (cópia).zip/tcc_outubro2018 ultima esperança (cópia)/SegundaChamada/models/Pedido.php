<?php
/**
 * Created by PhpStorm.
 * User: Jéssica Yohana Otto
 * Date: 18/04/2018
 * Time: 09:46
 */

require_once "Conexao.php";

class Pedido
{
    public $curso;
    public $turma;
    public $disciplina;
    public $professor;
    public $dt_inicial;
    public $motivo;


    public function __construct($curso, $turma, $disciplina, $professor, $dt_inicial, $motivo)
    {
        $this->curso = $curso;
        $this->turma = $turma;
        $this->disciplina = $disciplina;
        $this->professor = $professor;
        $this->dt_inicial = $dt_inicial;
        $this->motivo = $motivo;

    }

    /**
     * @return mixed
     */
    public function getCurso()
    {
        return $this->curso;
    }

    /**
     * @param mixed $curso
     */
    public function setCurso($curso)
    {
        $this->curso = $curso;
    }

    /**
     * @return mixed
     */
    public function getTurma()
    {
        return $this->turma;
    }

    /**
     * @param mixed $turma
     */
    public function setTurma($turma)
    {
        $this->turma = $turma;
    }

    /**
     * @return mixed
     */
    public function getDisciplina()
    {
        return $this->disciplina;
    }

    /**
     * @param mixed $disciplina
     */
    public function setDisciplina($disciplina)
    {
        $this->disciplina = $disciplina;
    }

    /**
     * @return mixed
     */
    public function getProfessor()
    {
        return $this->professor;
    }

    /**
     * @param mixed $data
     */
    public function setProfessor($professor)
    {
        $this->professor = $professor;
    }

    /**
     * @return mixed
     */
    public function getData()
    {
        return $this->dt_inicial;
    }

    /**
     * @param mixed $dt_inicial
     */
    public function setData($dt_inicial)
    {
        $this->dt_inicial = $dt_inicial;
    }


    /**
     * @return mixed
     */
    public function getMotivo()
    {
        return $this->motivo;
    }

    /**
     * @param mixed $motivo
     */
    public function setMotivo($motivo)
    {
        $this->motivo = $motivo;
    }


}


