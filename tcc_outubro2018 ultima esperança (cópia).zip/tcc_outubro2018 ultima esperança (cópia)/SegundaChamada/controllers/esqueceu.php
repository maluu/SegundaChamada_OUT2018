<?php

include "Conexao.php";

$email = $_POST['email'];

$query = mysql_query("SELECT * FROM tipo_user WHERE email = '".$email."'");

if(mysql_num_rows($query) > 0){

    $rs = mysql_fetch_array($query);

    $senha_banco = $rs["senha"];

    $msg = "<font face=\"Verdana\" size=\"2\">Recuperação de senha</font><br><br>";
    $msg .="<font face=\"Verdana\" size=\"2\"><strong>Sua senha é: </strong>".$senha_banco."</font><br><br>";

    $mensagem = $msg;
    $destinatario = $email;
    $assunto = "Recupeação de senha";
    $headers = "Bcc: [email]jessicayohanaotto@gmail.com[/email]";

    ini_set('sendmail_from', 'jessicayohanaotto@gmail.com');
    mail($destinatario, $assunto, $mensagem, $headers);

    $erro = "Mensagem enviada com sucesso!";
}
else{
    $erro = "Seu e-mail não consta em nossa base de dados!";
}

?>