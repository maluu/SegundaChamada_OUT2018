<?php
include "../models/CrudPedido.php";
//require_once "cadastro.html";

//print_r($_POST);

//print_r($_GET);

//if (isset($_POST['name']) AND !empty($_POST['name'])) {
//	print_r($_POST);

//	echo $_POST['name'];
//	echo $_REQUEST['name'];

//} else {
//	echo "ainda nao tem nada";
//}
//_______________________________________________________

function registrarPedido(){

    $curso         = $_POST['curso'];
    $turma         = $_POST['turma'];
    $disciplina    = $_POST['disciplina'];
    $professor     = $_POST['professor'];
    $dt_inicial    = $_POST['data'];
    $motivo        = $_POST['motivo'];

    //  if (!is_integer($nmatricula)) {
    //    header('location: ../views/cadastro.php?erro=verifique a matricula');
    //     exit();
    // }

    $pedido = new pedido($curso, $turma, $disciplina, $professor, $dt_inicial, $motivo);
    $crudpedido = new CrudPedido();
    $crudpedido->salvar($pedido);

    header('location:../views/profile.html');

}

if ($_GET['acao'] == 'salvar'){
    registrarPedido();
}

else
{

    echo "ERRO";
}
