-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE tipo_user (
nome Texto(1),
email Texto(1) PRIMARY KEY,
senha Texto(1)
)
;
CREATE TABLE curso (
num.servidor Texto(1),
nome Texto(1),
cod_curso Texto(1) PRIMARY KEY
)
;
CREATE TABLE aluno (
num.matricula Texto(1) PRIMARY KEY
)
;
CREATE TABLE Pedido (
status Texto(1),
anexo Texto(1),
dt_parecer Texto(1),
num.matricula Texto(1),
observacao Texto(1),
motivo Texto(1),
dt_pedido Texto(1),
num.servidor Texto(1),
dt_inicial Texto(1),
cod_pedido Texto(1) PRIMARY KEY,
dt_final Texto(1)
)
;
CREATE TABLE coordenador (
num.servidor Texto(1) PRIMARY KEY
)
;
CREATE TABLE turma (
cod_turma Texto(1) PRIMARY KEY,
cod_curso Texto(1),
nome Texto(1),
ano Texto(1)
)

;CREATE TABLE disciplina (
nome Texto(1),
cod_disciplina Texto(1) PRIMARY KEY
)
;
CREATE TABLE Rela��o_1 (
num.matricula Texto(1),
email Texto(1),
FOREIGN KEY(num.matricula) REFERENCES aluno (num.matricula),
FOREIGN KEY(email) REFERENCES tipo_user (email)
);

CREATE TABLE Rela��o_2 (
cod_turma Texto(1),
num.matricula Texto(1),
FOREIGN KEY(cod_turma) REFERENCES turma (cod_turma),
FOREIGN KEY(num.matricula) REFERENCES aluno (num.matricula)
);

CREATE TABLE Rela��o_3 (
num.servidor Texto(1),
email Texto(1),
FOREIGN KEY(num.servidor) REFERENCES coordenador (num.servidor),
FOREIGN KEY(email) REFERENCES tipo_user (email)
);

CREATE TABLE Rela��o_4 (
cod_turma Texto(1),
cod_curso Texto(1),
FOREIGN KEY(cod_turma) REFERENCES turma (cod_turma),
FOREIGN KEY(cod_curso) REFERENCES curso (cod_curso)
);

CREATE TABLE Rela��o_5 (
num.matricula Texto(1),
cod_pedido Texto(1),
FOREIGN KEY(num.matricula) REFERENCES aluno (num.matricula),
FOREIGN KEY(cod_pedido) REFERENCES Pedido (cod_pedido)
);

CREATE TABLE disc.pedido (
cod_pedido Texto(1),
cod_disciplina Texto(1),
FOREIGN KEY(cod_pedido) REFERENCES Pedido (cod_pedido),
FOREIGN KEY(cod_disciplina) REFERENCES disciplina (cod_disciplina)
)
;
CREATE TABLE Rela��o_6 (
num.servidor Texto(1),
cod_disciplina Texto(1),
FOREIGN KEY(num.servidor) REFERENCES coordenador (num.servidor),
FOREIGN KEY(cod_disciplina) REFERENCES disciplina (cod_disciplina)
);

CREATE TABLE dosc.turma (
cod_disciplina Texto(1),
cod_turma Texto(1),
FOREIGN KEY(cod_disciplina) REFERENCES disciplina (cod_disciplina)/*falha: chave estrangeira*/
)
;
